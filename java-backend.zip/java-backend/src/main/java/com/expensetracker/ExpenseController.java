package com.expensetracker;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.*;

// This handles all API routes the frontend will call
// @CrossOrigin allows the React frontend to connect
@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class ExpenseController {

    @Autowired
    private ExpenseService service;

    // ── GET /api/expenses ─────────────────────────────────
    // Returns all expenses as JSON
    @GetMapping("/expenses")
    public List<Expense> getAllExpenses() {
        return service.getAllExpenses();
    }

    // ── GET /api/expenses/category/{cat} ──────────────────
    // Returns expenses filtered by category
    // e.g. /api/expenses/category/Food
    @GetMapping("/expenses/category/{cat}")
    public List<Expense> getByCategory(@PathVariable String cat) {
        return service.getByCategory(cat);
    }

    // ── POST /api/expenses ────────────────────────────────
    // Adds a new expense
    // Body: { "desc": "Pizza", "amount": 150, "cat": "Food", "date": "2024-01-15" }
    @PostMapping("/expenses")
    public ResponseEntity<Expense> addExpense(@RequestBody Expense expense) {
        if (expense.getDesc() == null || expense.getDesc().isEmpty()) {
            return ResponseEntity.badRequest().build();
        }
        if (expense.getAmount() <= 0) {
            return ResponseEntity.badRequest().build();
        }
        Expense created = service.addExpense(expense);
        return ResponseEntity.ok(created);
    }

    // ── DELETE /api/expenses/{id} ─────────────────────────
    // Deletes an expense by ID
    @DeleteMapping("/expenses/{id}")
    public ResponseEntity<Map<String, String>> deleteExpense(@PathVariable Long id) {
        boolean deleted = service.deleteExpense(id);
        Map<String, String> response = new HashMap<>();
        if (deleted) {
            response.put("message", "Deleted successfully");
            return ResponseEntity.ok(response);
        } else {
            response.put("message", "Expense not found");
            return ResponseEntity.notFound().build();
        }
    }

    // ── GET /api/summary ──────────────────────────────────
    // Returns total, avg, max, count, and per-category totals
    @GetMapping("/summary")
    public Map<String, Object> getSummary() {
        return service.getSummary();
    }

    // ── GET /api/budget?amount=5000 ───────────────────────
    // Checks if total spending is within the given budget
    @GetMapping("/budget")
    public Map<String, Object> checkBudget(@RequestParam double amount) {
        return service.checkBudget(amount);
    }

    // ── GET /api/health ───────────────────────────────────
    // Simple check to see if backend is running
    @GetMapping("/health")
    public Map<String, String> health() {
        Map<String, String> status = new HashMap<>();
        status.put("status",  "running");
        status.put("message", "Java backend is up!");
        return status;
    }
}
