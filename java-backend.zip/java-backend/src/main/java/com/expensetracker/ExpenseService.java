package com.expensetracker;

import org.springframework.stereotype.Service;
import java.util.*;
import java.util.concurrent.atomic.AtomicLong;

// This is like our ExpenseManager.java from the console app
// It handles all the logic: add, delete, get, summary
@Service
public class ExpenseService {

    // Same ArrayList we used in the console app!
    private List<Expense> expenses = new ArrayList<>();
    private AtomicLong nextId = new AtomicLong(1);

    // ── Get all expenses ──────────────────────────────────
    public List<Expense> getAllExpenses() {
        return expenses;
    }

    // ── Add new expense ───────────────────────────────────
    public Expense addExpense(Expense expense) {
        expense.setId(nextId.getAndIncrement());
        expenses.add(expense);
        return expense;
    }

    // ── Delete expense by ID ──────────────────────────────
    public boolean deleteExpense(Long id) {
        return expenses.removeIf(e -> e.getId().equals(id));
    }

    // ── Get expenses filtered by category ─────────────────
    public List<Expense> getByCategory(String cat) {
        List<Expense> result = new ArrayList<>();
        for (Expense e : expenses) {
            if (e.getCat().equalsIgnoreCase(cat)) {
                result.add(e);
            }
        }
        return result;
    }

    // ── Get summary/report ────────────────────────────────
    // Same as our ReportGenerator.java from console app!
    public Map<String, Object> getSummary() {
        double total = 0;
        double max   = 0;

        for (Expense e : expenses) {
            total += e.getAmount();
            if (e.getAmount() > max) max = e.getAmount();
        }

        double avg = expenses.isEmpty() ? 0 : total / expenses.size();

        // Category breakdown
        String[] cats = {"Food", "Travel", "Academic", "Personal", "Bills", "Other"};
        Map<String, Double> byCategory = new LinkedHashMap<>();
        for (String cat : cats) {
            double catTotal = 0;
            for (Expense e : expenses) {
                if (e.getCat().equalsIgnoreCase(cat)) {
                    catTotal += e.getAmount();
                }
            }
            byCategory.put(cat, catTotal);
        }

        // Build response map
        Map<String, Object> summary = new HashMap<>();
        summary.put("count",      expenses.size());
        summary.put("total",      total);
        summary.put("avg",        Math.round(avg));
        summary.put("max",        max);
        summary.put("byCategory", byCategory);
        return summary;
    }

    // ── Check if over budget ──────────────────────────────
    public Map<String, Object> checkBudget(double budget) {
        double total = 0;
        for (Expense e : expenses) total += e.getAmount();

        Map<String, Object> result = new HashMap<>();
        result.put("budget",      budget);
        result.put("totalSpent",  total);
        result.put("remaining",   budget - total);
        result.put("isOver",      total > budget);
        result.put("percentage",  budget > 0 ? (total / budget) * 100 : 0);
        return result;
    }
}
