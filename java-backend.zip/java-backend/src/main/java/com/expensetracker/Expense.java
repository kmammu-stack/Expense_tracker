package com.expensetracker;

// This is like our Expense.java from the console app
// but now it works with the web API
public class Expense {

    private Long id;
    private String desc;       // description e.g. "Pizza"
    private double amount;     // e.g. 150.0
    private String cat;        // category e.g. "Food"
    private String date;       // e.g. "2024-01-15"

    // Empty constructor (Spring needs this)
    public Expense() {}

    // Full constructor
    public Expense(Long id, String desc, double amount, String cat, String date) {
        this.id     = id;
        this.desc   = desc;
        this.amount = amount;
        this.cat    = cat;
        this.date   = date;
    }

    // ── Getters ──────────────────────────────────────────
    public Long   getId()     { return id; }
    public String getDesc()   { return desc; }
    public double getAmount() { return amount; }
    public String getCat()    { return cat; }
    public String getDate()   { return date; }

    // ── Setters ──────────────────────────────────────────
    public void setId(Long id)        { this.id = id; }
    public void setDesc(String desc)  { this.desc = desc; }
    public void setAmount(double amt) { this.amount = amt; }
    public void setCat(String cat)    { this.cat = cat; }
    public void setDate(String date)  { this.date = date; }
}
